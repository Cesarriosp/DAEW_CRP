const tabla = document.getElementById("tablaIndicadores");
const form = document.getElementById("formIndicador");

async function cargarIndicadores() {
  const datos = await getIndicadores();
  tabla.innerHTML = "";

  datos.forEach(i => {
    tabla.innerHTML += `
      <tr>
        <td>${i.nombre}</td>
        <td>${i.tipo}</td>
        <td>${i.valor}</td>
        <td>
          <button class="btn btn-sm btn-warning" onclick='editar(${JSON.stringify(i)})'>Editar</button>
          <button class="btn btn-sm btn-danger" onclick="borrar(${i.id})">Eliminar</button>
        </td>
      </tr>
    `;
  });
}

form.addEventListener("submit", async e => {
  e.preventDefault();

  const indicador = {
    nombre: nombre.value,
    tipo: tipo.value,
    valor: valor.value
  };

  if (idIndicador.value) {
    await actualizarIndicador(idIndicador.value, indicador);
  } else {
    await crearIndicador(indicador);
  }

  form.reset();
  idIndicador.value = "";
  cargarIndicadores();
});

function editar(i) {
  idIndicador.value = i.id;
  nombre.value = i.nombre;
  tipo.value = i.tipo;
  valor.value = i.valor;
}

async function borrar(id) {
  if (confirm("¿Eliminar indicador?")) {
    await eliminarIndicador(id);
    cargarIndicadores();
  }
}

cargarIndicadores();
