const API_URL = "http://localhost:8080/api/indicadores";

async function getIndicadores() {
  const res = await fetch(API_URL);
  return res.json();
}

async function crearIndicador(data) {
  return fetch(API_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data)
  });
}

async function actualizarIndicador(id, data) {
  return fetch(`${API_URL}/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data)
  });
}

async function eliminarIndicador(id) {
  return fetch(`${API_URL}/${id}`, { method: "DELETE" });
}
