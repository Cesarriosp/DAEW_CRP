# EcoData Solutions - Aplicación Frontend

## Proyecto: DWES + Digitalización + Sostenibilidad

Aplicación web cliente desarrollada para **EcoData Solutions S.L.** que consume una API REST para gestionar indicadores de Digitalización y Sostenibilidad.

---

## 📋 Descripción del Proyecto

Esta aplicación frontend proporciona una interfaz clara, usable y responsive que permite:

- ✅ Consultar indicadores de Digitalización y Sostenibilidad
- ✅ Crear nuevos indicadores con validación de datos
- ✅ Editar indicadores existentes
- ✅ Eliminar indicadores
- ✅ Filtrar indicadores por múltiples criterios
- ✅ Visualizar estadísticas agregadas
- ✅ Ver detalles completos de cada indicador (modal)
- ✅ Galería de imágenes relacionada con la temática

---

## 🚀 Características Principales

### 1. **Página Principal (Index)**
- Presentación de la empresa y el proyecto
- Descripción del propósito de la aplicación
- Explicación de la relación con Digitalización y Sostenibilidad
- Navegación clara hacia todas las funcionalidades

### 2. **Gestión de Indicadores**
- **Listado**: Visualización de todos los indicadores con sus datos principales
- **Filtrado**: Dos criterios de filtrado (Categoría y Año) + búsqueda por nombre
- **CRUD Completo**:
  - Create: Formulario de alta con validación
  - Read: Vista de listado y detalle (modal)
  - Update: Formulario de edición
  - Delete: Eliminación con confirmación
- **Estadísticas**: Dashboard con métricas clave en tiempo real

### 3. **Vista de Resumen (Modal)**
- Modal informativo que muestra detalles completos del indicador
- Visualización con barra de progreso
- Información estructurada y clara

### 4. **Galería de Imágenes**
- Imágenes relacionadas con digitalización, sostenibilidad y tecnología
- Sistema de filtrado por categorías
- Modal para visualización ampliada
- Diseño responsive en grid

---

## 🛠️ Tecnologías Utilizadas

- **HTML5**: Estructura semántica
- **CSS3**: Estilos personalizados y animaciones
- **Bootstrap 5.3.2**: Framework CSS responsive
- **JavaScript ES6+**: Lógica de la aplicación
- **Font Awesome 6.5.1**: Iconografía
- **Unsplash**: Imágenes de alta calidad

---

## 📁 Estructura del Proyecto

```
RA8_CRP/
│
├── index.html              # Página principal
├── indicadores.html        # Gestión de indicadores
├── galeria.html            # Galería de imágenes
│
├── css/
│   └── styles.css          # Estilos personalizados
│
├── js/
│   ├── api-service.js      # Servicio API y utilidades
│   ├── indicadores.js      # Lógica de indicadores
│   └── galeria.js          # Lógica de galería
│
├── images/
│   └── hero-image.svg      # Imagen hero personalizada
│
└── README.md               # Este archivo
```

---

## ⚙️ Configuración

### 1. **Configurar la API REST**

Edita el archivo `js/api-service.js` y actualiza la URL base de tu API:

```javascript
this.baseUrl = 'http://localhost/api'; // Cambiar por la URL de tu API
```

### 2. **Estructura de Datos Esperada**

La API debe proporcionar indicadores con la siguiente estructura:

```json
{
  "id": 1,
  "nombre": "Nombre del Indicador",
  "categoria": "Digitalización|Sostenibilidad",
  "valor": 85,
  "unidad": "%",
  "fecha": "2026-01-15",
  "descripcion": "Descripción del indicador"
}
```

### 3. **Endpoints de la API**

La aplicación espera los siguientes endpoints:

- `GET /indicadores` - Obtener todos los indicadores
- `GET /indicadores/{id}` - Obtener un indicador específico
- `POST /indicadores` - Crear nuevo indicador
- `PUT /indicadores/{id}` - Actualizar indicador
- `DELETE /indicadores/{id}` - Eliminar indicador

---

## 🎯 Funcionalidades Implementadas

### ✅ Requisitos Cumplidos

1. **Página Principal Descriptiva** ✓
   - Propósito de la aplicación
   - Contexto del proyecto
   - Relación con Digitalización y Sostenibilidad

2. **Interfaz de Consulta de Indicadores** ✓
   - Listado completo de indicadores
   - Visualización de datos principales
   - Controles de filtrado (2+ criterios)
   - Opciones de edición y eliminación

3. **Formulario de Alta de Indicadores** ✓
   - Validación de datos
   - Mensajes de error informativos
   - Envío a la API mediante POST

4. **Interfaz de Modificación** ✓
   - Actualización mediante PUT
   - Validación de datos
   - Feedback al usuario

5. **Vista de Resumen (Modal)** ✓
   - Modal con información detallada
   - Visualización mejorada del indicador seleccionado

6. **Galería de Imágenes** ✓
   - Imágenes temáticas (digitalización, sostenibilidad, tecnología)
   - Integrada en el diseño general
   - Sistema de filtrado

7. **Diseño Responsive** ✓
   - Compatible con desktop, tablet y móvil
   - Estructura clara y organizada
   - Principios UI/UX aplicados

---

## 🎨 Validación de Datos

La aplicación incluye validación completa:

- **Nombre**: Obligatorio, 3-100 caracteres
- **Categoría**: Obligatorio, debe ser "Digitalización" o "Sostenibilidad"
- **Valor**: Obligatorio, número entre 0-100
- **Unidad**: Obligatorio, máximo 20 caracteres
- **Fecha**: Obligatorio, no puede ser futura
- **Descripción**: Obligatorio, 10-500 caracteres

---

## 📱 Responsive Design

La aplicación está optimizada para:

- **Desktop**: 1920px+
- **Laptop**: 1366px - 1920px
- **Tablet**: 768px - 1365px
- **Mobile**: 320px - 767px

---

## 🌐 Modo Demo

Si la API no está disponible, la aplicación funcionará en **modo demo** con datos de ejemplo:

- 8 indicadores predefinidos
- 4 de Digitalización
- 4 de Sostenibilidad
- Operaciones CRUD simuladas en memoria

---

## 🚀 Instalación y Uso

### Opción 1: XAMPP (Recomendado)

1. Copiar la carpeta `RA8_CRP` en `C:\xampp\htdocs\`
2. Iniciar Apache desde el panel de XAMPP
3. Abrir navegador en `http://localhost/RA8_CRP/`

### Opción 2: Servidor local

```bash
# Navegar a la carpeta del proyecto
cd RA8_CRP

# Iniciar servidor local (Python)
python -m http.server 8000

# O con Node.js (http-server)
npx http-server -p 8000
```

Luego abrir: `http://localhost:8000`

### Opción 3: Abrir directamente

Simplemente abrir `index.html` en el navegador (funcionalidad limitada sin API).

---

## 🔧 Personalización

### Cambiar Colores

Editar las variables CSS en `css/styles.css`:

```css
:root {
    --primary-color: #0d6efd;
    --success-color: #198754;
    --warning-color: #ffc107;
    --danger-color: #dc3545;
}
```

### Agregar Nuevas Imágenes a la Galería

En `galeria.html`, agregar un nuevo elemento:

```html
<div class="gallery-item" data-category="digitalizacion">
    <img src="URL_DE_LA_IMAGEN" alt="Descripción">
    <div class="gallery-overlay">
        <h5>Título</h5>
        <p>Descripción</p>
    </div>
</div>
```

---

## 📊 Características Técnicas

- **Sin dependencias de Node.js** (CDN para librerías)
- **Vanilla JavaScript** (ES6+)
- **Fetch API** para comunicación con backend
- **Bootstrap 5** para componentes UI
- **CSS Grid y Flexbox** para layouts
- **Animaciones CSS** para mejor UX

---

## 🐛 Solución de Problemas

### La API no responde

- Verificar que el backend esté ejecutándose
- Comprobar la URL en `js/api-service.js`
- Revisar CORS en el servidor backend
- La aplicación funcionará en modo demo automáticamente

### Los filtros no funcionan

- Verificar que los datos tengan la estructura correcta
- Abrir consola del navegador (F12) para ver errores

### Estilos no se aplican

- Verificar ruta de `css/styles.css`
- Limpiar caché del navegador (Ctrl + F5)

---

## 👨‍💻 Desarrollo

### Estructura de Código

- **Modular**: Separación clara entre API, UI y lógica de negocio
- **Reutilizable**: Clases y funciones genéricas
- **Mantenible**: Comentarios y documentación
- **Escalable**: Fácil agregar nuevas funcionalidades

### Mejores Prácticas Aplicadas

- Validación en cliente y servidor
- Manejo de errores robusto
- Feedback visual al usuario
- Accesibilidad (ARIA labels, semántica)
- SEO friendly (meta tags, estructura HTML)

---

## 📄 Licencia

Proyecto educativo para **EcoData Solutions S.L.**  
© 2026 - DWES + Digitalización + Sostenibilidad

---

## 📞 Soporte

Para dudas o problemas:

1. Revisar este README
2. Consultar la consola del navegador (F12)
3. Verificar la documentación de la API REST
4. Contactar al equipo de desarrollo

---

## 🎓 Créditos

- **Imágenes**: [Unsplash](https://unsplash.com)
- **Iconos**: [Font Awesome](https://fontawesome.com)
- **Framework**: [Bootstrap](https://getbootstrap.com)

---

## 🔜 Futuras Mejoras

- [ ] Gráficos interactivos (Chart.js)
- [ ] Exportación de datos (CSV, PDF)
- [ ] Sistema de autenticación
- [ ] Dashboard avanzado con métricas
- [ ] Modo oscuro/claro
- [ ] Soporte multiidioma
- [ ] PWA (Progressive Web App)
- [ ] Tests automatizados

---

**¡Gracias por usar EcoData Solutions!** 🌱💻
