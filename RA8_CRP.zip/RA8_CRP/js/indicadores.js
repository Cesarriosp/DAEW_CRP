/**
 * Script para la gestión de indicadores
 * Maneja la lógica de la página indicadores.html
 */

// Variables globales
let indicadoresData = [];
let filteredData = [];

// Elementos del DOM
const indicadoresList = document.getElementById('indicadoresList');
const emptyState = document.getElementById('emptyState');
const filterCategoria = document.getElementById('filterCategoria');
const filterFecha = document.getElementById('filterFecha');
const searchNombre = document.getElementById('searchNombre');
const btnLimpiarFiltros = document.getElementById('btnLimpiarFiltros');
const btnRefrescar = document.getElementById('btnRefrescar');

// Modales
const modalNuevoIndicador = new bootstrap.Modal(document.getElementById('modalNuevoIndicador'));
const modalEditarIndicador = new bootstrap.Modal(document.getElementById('modalEditarIndicador'));
const modalDetalleIndicador = new bootstrap.Modal(document.getElementById('modalDetalleIndicador'));

// Formularios
const formNuevoIndicador = document.getElementById('formNuevoIndicador');
const formEditarIndicador = document.getElementById('formEditarIndicador');

// Inicialización
document.addEventListener('DOMContentLoaded', () => {
    initializeEventListeners();
    loadIndicadores();
    
    // Establecer fecha actual como máximo en los inputs de fecha
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('nuevoFecha').setAttribute('max', today);
    document.getElementById('editarFecha').setAttribute('max', today);
});

/**
 * Inicializar event listeners
 */
function initializeEventListeners() {
    // Filtros
    filterCategoria.addEventListener('change', applyFilters);
    filterFecha.addEventListener('change', applyFilters);
    searchNombre.addEventListener('input', applyFilters);
    
    // Botones de acción
    btnLimpiarFiltros.addEventListener('click', clearFilters);
    btnRefrescar.addEventListener('click', loadIndicadores);
    
    // Formulario nuevo indicador
    document.getElementById('btnGuardarIndicador').addEventListener('click', handleCreateIndicador);
    
    // Formulario editar indicador
    document.getElementById('btnActualizarIndicador').addEventListener('click', handleUpdateIndicador);
    
    // Reset de formularios al cerrar modales
    document.getElementById('modalNuevoIndicador').addEventListener('hidden.bs.modal', () => {
        formNuevoIndicador.reset();
        UIUtils.resetFormValidation(formNuevoIndicador);
    });
    
    document.getElementById('modalEditarIndicador').addEventListener('hidden.bs.modal', () => {
        formEditarIndicador.reset();
        UIUtils.resetFormValidation(formEditarIndicador);
    });
}

/**
 * Cargar indicadores desde la API
 */
async function loadIndicadores() {
    try {
        UIUtils.toggleLoading(true);
        
        // Simular datos si no hay API disponible
        if (apiService.baseUrl.includes('localhost/api')) {
            // Datos de ejemplo para desarrollo
            indicadoresData = getDemoData();
        } else {
            indicadoresData = await apiService.getIndicadores();
        }
        
        filteredData = [...indicadoresData];
        renderIndicadores();
        updateStats();
        
        UIUtils.toggleLoading(false);
    } catch (error) {
        UIUtils.toggleLoading(false);
        console.error('Error al cargar indicadores:', error);
        UIUtils.showAlert('Error al cargar los indicadores. Mostrando datos de ejemplo.', 'warning');
        
        // Usar datos de ejemplo en caso de error
        indicadoresData = getDemoData();
        filteredData = [...indicadoresData];
        renderIndicadores();
        updateStats();
    }
}

/**
 * Renderizar lista de indicadores
 */
function renderIndicadores() {
    if (filteredData.length === 0) {
        indicadoresList.innerHTML = '';
        emptyState.classList.remove('d-none');
        return;
    }
    
    emptyState.classList.add('d-none');
    
    const html = filteredData.map(indicador => createIndicadorCard(indicador)).join('');
    indicadoresList.innerHTML = html;
}

/**
 * Crear tarjeta HTML para un indicador
 */
function createIndicadorCard(indicador) {
    const categoriaClass = indicador.categoria.toLowerCase();
    
    return `
        <div class="indicator-card ${categoriaClass} fade-in">
            <div class="indicator-header">
                <h3 class="indicator-title">${indicador.nombre}</h3>
                <span class="indicator-category ${categoriaClass}">${indicador.categoria}</span>
            </div>
            <div class="indicator-body">
                <p><strong>Valor:</strong> ${indicador.valor} ${indicador.unidad}</p>
                <p><strong>Fecha:</strong> ${UIUtils.formatDate(indicador.fecha)}</p>
                <p><strong>Descripción:</strong> ${indicador.descripcion}</p>
            </div>
            <div class="indicator-actions">
                <button class="btn btn-sm btn-info text-white btn-icon" onclick="showDetalle(${indicador.id})">
                    <i class="fas fa-eye"></i> Ver Más
                </button>
                <button class="btn btn-sm btn-primary btn-icon" onclick="editIndicador(${indicador.id})">
                    <i class="fas fa-edit"></i> Editar
                </button>
                <button class="btn btn-sm btn-danger btn-icon" onclick="deleteIndicador(${indicador.id})">
                    <i class="fas fa-trash"></i> Eliminar
                </button>
            </div>
        </div>
    `;
}

/**
 * Aplicar filtros a los indicadores
 */
function applyFilters() {
    const categoriaFilter = filterCategoria.value;
    const fechaFilter = filterFecha.value;
    const nombreSearch = searchNombre.value.toLowerCase().trim();
    
    filteredData = indicadoresData.filter(indicador => {
        // Filtro por categoría
        if (categoriaFilter && indicador.categoria !== categoriaFilter) {
            return false;
        }
        
        // Filtro por año
        if (fechaFilter) {
            const indicadorYear = new Date(indicador.fecha).getFullYear().toString();
            if (indicadorYear !== fechaFilter) {
                return false;
            }
        }
        
        // Búsqueda por nombre
        if (nombreSearch && !indicador.nombre.toLowerCase().includes(nombreSearch)) {
            return false;
        }
        
        return true;
    });
    
    renderIndicadores();
    updateStats();
}

/**
 * Limpiar todos los filtros
 */
function clearFilters() {
    filterCategoria.value = '';
    filterFecha.value = '';
    searchNombre.value = '';
    applyFilters();
}

/**
 * Actualizar estadísticas
 */
function updateStats() {
    const total = filteredData.length;
    const digitalizacion = filteredData.filter(i => i.categoria === 'Digitalización').length;
    const sostenibilidad = filteredData.filter(i => i.categoria === 'Sostenibilidad').length;
    
    const promedioValor = total > 0
        ? (filteredData.reduce((sum, i) => sum + parseFloat(i.valor), 0) / total).toFixed(1)
        : 0;
    
    document.getElementById('totalIndicadores').textContent = total;
    document.getElementById('totalDigitalizacion').textContent = digitalizacion;
    document.getElementById('totalSostenibilidad').textContent = sostenibilidad;
    document.getElementById('promedioValor').textContent = promedioValor + '%';
}

/**
 * Mostrar detalle de un indicador
 */
function showDetalle(id) {
    const indicador = indicadoresData.find(i => i.id === id);
    if (!indicador) return;
    
    const categoriaClass = indicador.categoria.toLowerCase();
    const detailHtml = `
        <div class="row g-3">
            <div class="col-12">
                <div class="card border-${categoriaClass === 'digitalización' ? 'primary' : 'success'}">
                    <div class="card-body">
                        <h4 class="card-title mb-3">${indicador.nombre}</h4>
                        <span class="badge badge-custom bg-${categoriaClass === 'digitalización' ? 'primary' : 'success'} mb-3">
                            ${indicador.categoria}
                        </span>
                        
                        <div class="row mt-3">
                            <div class="col-md-6">
                                <p class="mb-2"><strong><i class="fas fa-chart-line me-2 text-primary"></i>Valor:</strong></p>
                                <h3 class="text-${categoriaClass === 'digitalización' ? 'primary' : 'success'}">${indicador.valor} ${indicador.unidad}</h3>
                            </div>
                            <div class="col-md-6">
                                <p class="mb-2"><strong><i class="fas fa-calendar me-2 text-primary"></i>Fecha de Registro:</strong></p>
                                <p class="h5">${UIUtils.formatDate(indicador.fecha)}</p>
                            </div>
                        </div>
                        
                        <hr class="my-3">
                        
                        <p class="mb-2"><strong><i class="fas fa-file-alt me-2 text-primary"></i>Descripción:</strong></p>
                        <p class="text-muted">${indicador.descripcion}</p>
                        
                        <div class="progress mt-4" style="height: 30px;">
                            <div class="progress-bar bg-${categoriaClass === 'digitalización' ? 'primary' : 'success'}" 
                                 role="progressbar" 
                                 style="width: ${indicador.valor}%;" 
                                 aria-valuenow="${indicador.valor}" 
                                 aria-valuemin="0" 
                                 aria-valuemax="100">
                                ${indicador.valor}%
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    document.getElementById('detalleIndicadorContent').innerHTML = detailHtml;
    modalDetalleIndicador.show();
}

/**
 * Editar indicador
 */
function editIndicador(id) {
    const indicador = indicadoresData.find(i => i.id === id);
    if (!indicador) return;
    
    document.getElementById('editarId').value = indicador.id;
    document.getElementById('editarNombre').value = indicador.nombre;
    document.getElementById('editarCategoria').value = indicador.categoria;
    document.getElementById('editarValor').value = indicador.valor;
    document.getElementById('editarUnidad').value = indicador.unidad;
    document.getElementById('editarFecha').value = indicador.fecha;
    document.getElementById('editarDescripcion').value = indicador.descripcion;
    
    modalEditarIndicador.show();
}

/**
 * Eliminar indicador
 */
async function deleteIndicador(id) {
    const indicador = indicadoresData.find(i => i.id === id);
    if (!indicador) return;
    
    const confirmDelete = UIUtils.confirm(
        `¿Está seguro de que desea eliminar el indicador "${indicador.nombre}"?\n\nEsta acción no se puede deshacer.`
    );
    
    if (!confirmDelete) return;
    
    try {
        await apiService.eliminarIndicador(id);
        UIUtils.showAlert('Indicador eliminado correctamente', 'success');
        loadIndicadores();
    } catch (error) {
        console.error('Error al eliminar:', error);
        
        // Simular eliminación en datos de ejemplo
        const index = indicadoresData.findIndex(i => i.id === id);
        if (index !== -1) {
            indicadoresData.splice(index, 1);
            filteredData = [...indicadoresData];
            renderIndicadores();
            updateStats();
            UIUtils.showAlert('Indicador eliminado correctamente (modo demo)', 'success');
        } else {
            UIUtils.showAlert('Error al eliminar el indicador', 'danger');
        }
    }
}

/**
 * Manejar creación de nuevo indicador
 */
async function handleCreateIndicador() {
    const form = formNuevoIndicador;
    
    if (!UIUtils.validateForm(form)) {
        UIUtils.showAlert('Por favor, complete todos los campos requeridos correctamente', 'warning');
        return;
    }
    
    const data = {
        nombre: document.getElementById('nuevoNombre').value,
        categoria: document.getElementById('nuevoCategoria').value,
        valor: document.getElementById('nuevoValor').value,
        unidad: document.getElementById('nuevoUnidad').value,
        fecha: document.getElementById('nuevoFecha').value,
        descripcion: document.getElementById('nuevoDescripcion').value
    };
    
    // Validar datos
    const validation = IndicadorValidator.validate(data);
    if (!validation.isValid) {
        UIUtils.showAlert(validation.errors.join('<br>'), 'danger');
        return;
    }
    
    try {
        const cleanData = IndicadorValidator.sanitize(data);
        await apiService.crearIndicador(cleanData);
        
        modalNuevoIndicador.hide();
        UIUtils.showAlert('Indicador creado correctamente', 'success');
        loadIndicadores();
    } catch (error) {
        console.error('Error al crear:', error);
        
        // Simular creación en datos de ejemplo
        const newIndicador = {
            id: Math.max(...indicadoresData.map(i => i.id), 0) + 1,
            ...IndicadorValidator.sanitize(data)
        };
        indicadoresData.push(newIndicador);
        filteredData = [...indicadoresData];
        renderIndicadores();
        updateStats();
        
        modalNuevoIndicador.hide();
        UIUtils.showAlert('Indicador creado correctamente (modo demo)', 'success');
    }
}

/**
 * Manejar actualización de indicador
 */
async function handleUpdateIndicador() {
    const form = formEditarIndicador;
    
    if (!UIUtils.validateForm(form)) {
        UIUtils.showAlert('Por favor, complete todos los campos requeridos correctamente', 'warning');
        return;
    }
    
    const id = document.getElementById('editarId').value;
    const data = {
        nombre: document.getElementById('editarNombre').value,
        categoria: document.getElementById('editarCategoria').value,
        valor: document.getElementById('editarValor').value,
        unidad: document.getElementById('editarUnidad').value,
        fecha: document.getElementById('editarFecha').value,
        descripcion: document.getElementById('editarDescripcion').value
    };
    
    // Validar datos
    const validation = IndicadorValidator.validate(data);
    if (!validation.isValid) {
        UIUtils.showAlert(validation.errors.join('<br>'), 'danger');
        return;
    }
    
    try {
        const cleanData = IndicadorValidator.sanitize(data);
        await apiService.actualizarIndicador(id, cleanData);
        
        modalEditarIndicador.hide();
        UIUtils.showAlert('Indicador actualizado correctamente', 'success');
        loadIndicadores();
    } catch (error) {
        console.error('Error al actualizar:', error);
        
        // Simular actualización en datos de ejemplo
        const index = indicadoresData.findIndex(i => i.id === parseInt(id));
        if (index !== -1) {
            indicadoresData[index] = {
                id: parseInt(id),
                ...IndicadorValidator.sanitize(data)
            };
            filteredData = [...indicadoresData];
            renderIndicadores();
            updateStats();
            
            modalEditarIndicador.hide();
            UIUtils.showAlert('Indicador actualizado correctamente (modo demo)', 'success');
        }
    }
}

/**
 * Obtener datos de demostración
 */
function getDemoData() {
    return [
        {
            id: 1,
            nombre: 'Adopción de Herramientas Digitales',
            categoria: 'Digitalización',
            valor: 85,
            unidad: '%',
            fecha: '2026-01-15',
            descripcion: 'Porcentaje de empleados que utilizan herramientas digitales colaborativas diariamente para mejorar la productividad y comunicación.'
        },
        {
            id: 2,
            nombre: 'Reducción de Emisiones de CO₂',
            categoria: 'Sostenibilidad',
            valor: 45,
            unidad: 'ton CO₂',
            fecha: '2026-01-20',
            descripcion: 'Reducción acumulada de emisiones de dióxido de carbono en toneladas gracias a la implementación de energías renovables.'
        },
        {
            id: 3,
            nombre: 'Automatización de Procesos',
            categoria: 'Digitalización',
            valor: 70,
            unidad: '%',
            fecha: '2025-12-10',
            descripcion: 'Nivel de automatización de procesos empresariales mediante RPA y sistemas de gestión integrados.'
        },
        {
            id: 4,
            nombre: 'Consumo de Energía Renovable',
            categoria: 'Sostenibilidad',
            valor: 62,
            unidad: '%',
            fecha: '2026-01-25',
            descripcion: 'Porcentaje del consumo energético total proveniente de fuentes renovables como solar y eólica.'
        },
        {
            id: 5,
            nombre: 'Capacitación Digital del Personal',
            categoria: 'Digitalización',
            valor: 78,
            unidad: '%',
            fecha: '2025-11-30',
            descripcion: 'Porcentaje de empleados que han completado programas de formación en competencias digitales durante el último año.'
        },
        {
            id: 6,
            nombre: 'Tasa de Reciclaje',
            categoria: 'Sostenibilidad',
            valor: 88,
            unidad: '%',
            fecha: '2026-01-18',
            descripcion: 'Porcentaje de residuos generados que son reciclados o reutilizados mediante programas de economía circular.'
        },
        {
            id: 7,
            nombre: 'Uso de Cloud Computing',
            categoria: 'Digitalización',
            valor: 92,
            unidad: '%',
            fecha: '2026-01-10',
            descripcion: 'Porcentaje de infraestructura IT migrada a soluciones cloud para mejorar escalabilidad y reducir costos.'
        },
        {
            id: 8,
            nombre: 'Eficiencia en el Uso del Agua',
            categoria: 'Sostenibilidad',
            valor: 55,
            unidad: '%',
            fecha: '2025-12-20',
            descripcion: 'Mejora en la eficiencia del uso de recursos hídricos mediante sistemas de reutilización y optimización.'
        }
    ];
}
