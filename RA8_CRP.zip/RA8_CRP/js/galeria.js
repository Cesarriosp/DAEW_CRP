/**
 * Script para la galeria de imagenes
 */

document.addEventListener('DOMContentLoaded', () => {
    initializeGallery();
});

/**
 * Esta funcion inicia la galería
 */
function initializeGallery() {
    const filterButtons = document.querySelectorAll('#galleryTabs .nav-link');
    const galleryItems = document.querySelectorAll('.gallery-item');
    const imageModal = new bootstrap.Modal(document.getElementById('imageModal'));
    
    // Event listeners para filtros
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Actualizar estado activo de botones
            filterButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            
            // Obtener categoria seleccionada
            const filter = this.getAttribute('data-filter');
            
            // Filtro imagenes
            filterGallery(filter, galleryItems);
        });
    });
    
    // Event listeners para imagenes
    galleryItems.forEach(item => {
        item.addEventListener('click', function() {
            const img = this.querySelector('img');
            const title = this.querySelector('.gallery-overlay h5').textContent;
            const description = this.querySelector('.gallery-overlay p').textContent;
            
            // Actualizar contenido del modal
            document.getElementById('imageModalImg').src = img.src;
            document.getElementById('imageModalImg').alt = img.alt;
            document.getElementById('imageModalTitle').textContent = title;
            document.getElementById('imageModalDescription').textContent = description;
            
            // Mostrar modal
            imageModal.show();
        });
    });
    
    // Animación de entrada
    animateGalleryItems(galleryItems);
}

/**
 * Filtrar galería por categoría
 * @param {string} filter - Categoría a filtrar
 * @param {NodeList} items - Elementos de la galería
 */
function filterGallery(filter, items) {
    items.forEach((item, index) => {
        const category = item.getAttribute('data-category');
        
        if (filter === 'all' || category === filter) {
            // Mostrar elemento con animación
            item.style.display = 'block';
            setTimeout(() => {
                item.style.opacity = '0';
                item.style.transform = 'scale(0.8)';
                setTimeout(() => {
                    item.style.transition = 'all 0.3s ease';
                    item.style.opacity = '1';
                    item.style.transform = 'scale(1)';
                }, 50);
            }, index * 30);
        } else {
            // Ocultar elemento
            item.style.transition = 'all 0.2s ease';
            item.style.opacity = '0';
            item.style.transform = 'scale(0.8)';
            setTimeout(() => {
                item.style.display = 'none';
            }, 200);
        }
    });
}

/**
 * Animar entrada de elementos de galería
 * @param {NodeList} items - Elementos de la galería
 */
function animateGalleryItems(items) {
    items.forEach((item, index) => {
        item.style.opacity = '0';
        item.style.transform = 'translateY(20px)';
        
        setTimeout(() => {
            item.style.transition = 'all 0.5s ease';
            item.style.opacity = '1';
            item.style.transform = 'translateY(0)';
        }, index * 50);
    });
}

/**
 * Lazy loading de imágenes (opcional, para optimización)
 */
function lazyLoadImages() {
    const images = document.querySelectorAll('.gallery-item img');
    
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.classList.add('loaded');
                observer.unobserve(img);
            }
        });
    });
    
    images.forEach(img => imageObserver.observe(img));
}

/**
 * Búsqueda en galería (funcionalidad adicional)
 */
function searchGallery(searchTerm) {
    const items = document.querySelectorAll('.gallery-item');
    const normalizedSearch = searchTerm.toLowerCase().trim();
    
    items.forEach(item => {
        const title = item.querySelector('.gallery-overlay h5').textContent.toLowerCase();
        const description = item.querySelector('.gallery-overlay p').textContent.toLowerCase();
        
        if (title.includes(normalizedSearch) || description.includes(normalizedSearch)) {
            item.style.display = 'block';
        } else {
            item.style.display = 'none';
        }
    });
}

/**
 * Exportar imagen (funcionalidad adicional)
 */
function downloadImage(imageSrc, imageName) {
    const link = document.createElement('a');
    link.href = imageSrc;
    link.download = imageName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}
