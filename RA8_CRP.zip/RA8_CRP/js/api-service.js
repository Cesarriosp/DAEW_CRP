
class ApiService {
    constructor() {
        this.baseUrl = 'http://localhost:7093/api/Indicadores'; // Conexion con la api que hicimos para amelia
        this.endpoints = {
            indicadores: '/indicadores',
            stats: '/indicadores/stats'
        };
    }

    /**
     * Gracias a esto podemos realizar peticiones HTTP
     * @param {string} url - URL del endpoint
     * @param {object} options - Opciones de la petición (método, headers, body)
     * @returns {Promise} - Respuesta de la API
     */
    async request(url, options = {}) {
        try {
            const config = {
                headers: {
                    'Content-Type': 'application/json',
                    ...options.headers
                },
                ...options
            };

            const response = await fetch(url, config);
            
            // Si la respuesta no es exitosa, nos lanza error
            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.message || `Error HTTP: ${response.status}`);
            }

            // Si es DELETE sin contenido, hnos devuelve exito
            if (response.status === 204) {
                return { success: true };
            }

            return await response.json();
        } catch (error) {
            console.error('Error en la petición API:', error);
            throw error;
        }
    }

    /**
     * Obtener todos los indicadores
     * @returns {Promise<Array>} - Lista de indicadores
     */
    async getIndicadores() {
        const url = `${this.baseUrl}${this.endpoints.indicadores}`;
        return await this.request(url, { method: 'GET' });
    }

    /**
     * Obtener un indicador por ID
     * @param {number|string} id - ID del indicador
     * @returns {Promise<Object>} - Datos del indicador
     */
    async getIndicadorById(id) {
        const url = `${this.baseUrl}${this.endpoints.indicadores}/${id}`;
        return await this.request(url, { method: 'GET' });
    }

    /**
     * Crear un nuevo indicador
     * @param {Object} data - Datos del indicador a crear
     * @returns {Promise<Object>} - Indicador creado
     */
    async crearIndicador(data) {
        const url = `${this.baseUrl}${this.endpoints.indicadores}`;
        return await this.request(url, {
            method: 'POST',
            body: JSON.stringify(data)
        });
    }

    /**
     * Actualizar un indicador existente
     * @param {number|string} id - ID del indicador
     * @param {Object} data - Datos actualizados del indicador
     * @returns {Promise<Object>} - Indicador actualizado
     */
    async actualizarIndicador(id, data) {
        const url = `${this.baseUrl}${this.endpoints.indicadores}/${id}`;
        return await this.request(url, {
            method: 'PUT',
            body: JSON.stringify(data)
        });
    }

    /**
     * Eliminar un indicador
     * @param {number|string} id - ID del indicador a eliminar
     * @returns {Promise<Object>} - Resultado de la eliminación
     */
    async eliminarIndicador(id) {
        const url = `${this.baseUrl}${this.endpoints.indicadores}/${id}`;
        return await this.request(url, { method: 'DELETE' });
    }

    /**
     * Obtener estadísticas de indicadores
     * @returns {Promise<Object>} - Estadísticas agregadas
     */
    async getStats() {
        const url = `${this.baseUrl}${this.endpoints.stats}`;
        return await this.request(url, { method: 'GET' });
    }
}

/**
 * Clase para validación de datos de indicadores
 */
class IndicadorValidator {
    /**
     * Validar datos de un indicador
     * @param {Object} data - Datos a validar
     * @returns {Object} - Objeto con isValid y errores
     */
    static validate(data) {
        const errors = [];

        // Validar nombre
        if (!data.nombre || data.nombre.trim().length === 0) {
            errors.push('El nombre del indicador es obligatorio');
        } else if (data.nombre.trim().length < 3) {
            errors.push('El nombre debe tener al menos 3 caracteres');
        } else if (data.nombre.trim().length > 100) {
            errors.push('El nombre no puede exceder 100 caracteres');
        }

        // Validar categoría
        const categoriasValidas = ['Digitalización', 'Sostenibilidad'];
        if (!data.categoria || !categoriasValidas.includes(data.categoria)) {
            errors.push('Debe seleccionar una categoría válida (Digitalización o Sostenibilidad)');
        }

        // Validar valor
        if (data.valor === undefined || data.valor === null || data.valor === '') {
            errors.push('El valor del indicador es obligatorio');
        } else {
            const valor = parseFloat(data.valor);
            if (isNaN(valor)) {
                errors.push('El valor debe ser un número válido');
            } else if (valor < 0 || valor > 100) {
                errors.push('El valor debe estar entre 0 y 100');
            }
        }

        // Validar unidad
        if (!data.unidad || data.unidad.trim().length === 0) {
            errors.push('La unidad de medida es obligatoria');
        } else if (data.unidad.trim().length > 20) {
            errors.push('La unidad no puede exceder 20 caracteres');
        }

        // Validar fecha
        if (!data.fecha) {
            errors.push('La fecha de registro es obligatoria');
        } else {
            const fecha = new Date(data.fecha);
            if (isNaN(fecha.getTime())) {
                errors.push('La fecha no es válida');
            } else {
                const hoy = new Date();
                if (fecha > hoy) {
                    errors.push('La fecha no puede ser futura');
                }
            }
        }

        // Validar descripción
        if (!data.descripcion || data.descripcion.trim().length === 0) {
            errors.push('La descripción es obligatoria');
        } else if (data.descripcion.trim().length < 10) {
            errors.push('La descripción debe tener al menos 10 caracteres');
        } else if (data.descripcion.trim().length > 500) {
            errors.push('La descripción no puede exceder 500 caracteres');
        }

        return {
            isValid: errors.length === 0,
            errors: errors
        };
    }

    /**
     * Limpiar y formatear datos del indicador
     * @param {Object} data - Datos a limpiar
     * @returns {Object} - Datos limpios
     */
    static sanitize(data) {
        return {
            nombre: data.nombre?.trim() || '',
            categoria: data.categoria?.trim() || '',
            valor: parseFloat(data.valor) || 0,
            unidad: data.unidad?.trim() || '',
            fecha: data.fecha || '',
            descripcion: data.descripcion?.trim() || ''
        };
    }
}

/**
 * Utilidades para manejo de UI
 */
class UIUtils {
    /**
     * Mostrar mensaje de alerta
     * @param {string} message - Mensaje a mostrar
     * @param {string} type - Tipo de alerta (success, danger, warning, info)
     * @param {string} containerId - ID del contenedor donde mostrar la alerta
     */
    static showAlert(message, type = 'info', containerId = 'alertSection') {
        const container = document.getElementById(containerId);
        if (!container) return;

        const alertId = 'alert-' + Date.now();
        const alertHtml = `
            <div id="${alertId}" class="alert alert-${type} alert-dismissible fade show alert-custom" role="alert">
                <i class="fas fa-${this.getIconForType(type)} me-2"></i>
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        `;

        container.innerHTML = alertHtml;

        // Auto-ocultar después de 5 segundos
        setTimeout(() => {
            const alertElement = document.getElementById(alertId);
            if (alertElement) {
                const bsAlert = bootstrap.Alert.getOrCreateInstance(alertElement);
                bsAlert.close();
            }
        }, 5000);
    }

    /**
     * Obtener icono de FontAwesome según el tipo de alerta
     * @param {string} type - Tipo de alerta
     * @returns {string} - Nombre del icono
     */
    static getIconForType(type) {
        const icons = {
            success: 'check-circle',
            danger: 'exclamation-triangle',
            warning: 'exclamation-circle',
            info: 'info-circle'
        };
        return icons[type] || 'info-circle';
    }

    /**
     * Mostrar/ocultar spinner de carga
     * @param {boolean} show - Mostrar u ocultar
     */
    static toggleLoading(show) {
        const spinner = document.getElementById('loadingSpinner');
        const list = document.getElementById('indicadoresList');
        
        if (spinner && list) {
            if (show) {
                spinner.classList.remove('d-none');
                list.classList.add('d-none');
            } else {
                spinner.classList.add('d-none');
                list.classList.remove('d-none');
            }
        }
    }

    /**
     * Formatear fecha para visualización
     * @param {string} fecha - Fecha en formato ISO
     * @returns {string} - Fecha formateada
     */
    static formatDate(fecha) {
        const date = new Date(fecha);
        const options = { year: 'numeric', month: 'long', day: 'numeric' };
        return date.toLocaleDateString('es-ES', options);
    }

    /**
     * Confirmar acción con el usuario
     * @param {string} message - Mensaje de confirmación
     * @returns {boolean} - true si confirma, false si cancela
     */
    static confirm(message) {
        return window.confirm(message);
    }

    /**
     * Validar formulario de Bootstrap
     * @param {HTMLFormElement} form - Formulario a validar
     * @returns {boolean} - true si es válido
     */
    static validateForm(form) {
        if (!form.checkValidity()) {
            form.classList.add('was-validated');
            return false;
        }
        return true;
    }

    /**
     * Resetear validación de formulario
     * @param {HTMLFormElement} form - Formulario a resetear
     */
    static resetFormValidation(form) {
        form.classList.remove('was-validated');
    }
}

// Exportar instancia global del servicio API
const apiService = new ApiService();
